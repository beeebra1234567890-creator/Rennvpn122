package com.example.wgclient

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray

/**
 * VPN-сервис для VLESS: поднимает TUN-интерфейс и отдаёт его fd в Xray-core
 * (tun-inbound). Сам процесс приложения исключён из VPN, поэтому исходящие
 * соединения Xray к серверу не зацикливаются в туннель.
 */
class XrayVpnService : VpnService() {

    private var core: CoreController? = null
    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null

    // gomobile: Go int → Java long
    private val callback = object : CoreCallbackHandler {
        override fun startup(): Long = 0
        override fun shutdown(): Long = 0
        override fun onEmitStatus(code: Long, message: String?): Long = 0
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        showForeground() // после startForegroundService обязателен в течение 5 с
        val config = intent?.getStringExtra(EXTRA_CONFIG)
        if (intent?.action != ACTION_START || config == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        worker?.interrupt()
        worker = Thread({ start(config) }, "xray-start").also { it.start() }
        return START_NOT_STICKY
    }

    private fun start(config: String) {
        try {
            Libv2ray.initCoreEnv(filesDir.absolutePath, "")

            val builder = Builder()
                .setSession("RENT VPN")
                .setMtu(1500)
                .addAddress("172.19.0.1", 30)
                .addAddress("fdfe:dcba:9876::1", 126)
                .addRoute("0.0.0.0", 0)
                .addRoute("::", 0)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")
            // Не заворачиваем в туннель собственный трафик Xray (иначе петля)
            runCatching { builder.addDisallowedApplication(packageName) }

            val pfd = builder.establish() ?: throw IllegalStateException("Android не выдал VPN-интерфейс (нет разрешения?)")
            tun = pfd

            val controller = Libv2ray.newCoreController(callback)
            core = controller
            controller.startLoop(config, pfd.fd)

            VpnController.setState(VpnState.CONNECTED)
        } catch (e: Throwable) {
            VpnController.fail("Не удалось подключиться: ${e.message ?: e.javaClass.simpleName}")
            cleanup()
            stopSelf()
        }
    }

    private fun cleanup() {
        runCatching { core?.stopLoop() }
        core = null
        runCatching { tun?.close() }
        tun = null
    }

    override fun onRevoke() {
        // Пользователь отключил VPN из системных настроек
        cleanup()
        VpnController.setState(VpnState.DISCONNECTED)
        stopSelf()
    }

    override fun onDestroy() {
        worker?.interrupt()
        cleanup()
        VpnController.setState(VpnState.DISCONNECTED)
        super.onDestroy()
    }

    private fun showForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "VPN", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("RENT VPN")
            .setContentText("VPN подключается…")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    companion object {
        const val ACTION_START = "com.rentvpn.client.START"
        const val EXTRA_CONFIG = "xray_config"
        private const val CHANNEL = "rentvpn"
        private const val NOTIFICATION_ID = 1
    }
}
